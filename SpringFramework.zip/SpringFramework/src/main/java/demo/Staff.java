package demo;

public interface Staff {

	public void assist();
}
