package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		ApplicationContext context = 
//				new ClassPathXmlApplicationContext("resources/spring.xml");
		
//		Doctor doctor = context.getBean(Doctor.class);
//		Nurse nurse = context.getBean(Nurse.class);
//		Nurse nurse = (Nurse)context.getBean("nurse");
//		doctor.assist();
//		nurse.assist();
//		Staff staff = context.getBean(Doctor.class);
//		staff.assist();
//		Staff staff = context.getBean(Nurse.class);
//		staff.assist();
		
//		Doctor doc = context.getBean(Doctor.class);
//		doc.assist();
//		System.out.println(doc.getQualification());
		
//		Doctor doc = context.getBean(Doctor.class);
//		doc.assist();
		
		ApplicationContext context = 
				new AnnotationConfigApplicationContext(BeanConfig.class);
		
		Doctor doc = context.getBean(Doctor.class);
		doc.assist();
	}

}
