package demo;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class xmlParserDemo {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		// TODO Auto-generated method stub
		File file = new File("C:\\Users\\babua\\eclipse-workspace\\SpringFramework\\src\\main\\java\\resources\\gfg.xml");
		
		DocumentBuilderFactory dbf
        = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    Document doc = db.parse(file);
    doc.getDocumentElement().normalize();
    
    XPath xPath =  XPathFactory.newInstance().newXPath();

    System.out.println(
        "Root element: "
        + doc.getDocumentElement().getNodeName());
    
 
//    NodeList nodeList
//        = doc.getElementsByTagName("geek");
    
    String expression = "/class/geek[1]";	        
    NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(
       doc, XPathConstants.NODESET);
 
    for (int i = 0; i < nodeList.getLength(); ++i) {
        Node node = nodeList.item(i);
        System.out.println("\nNode Name :"
                           + node.getNodeName());
        if(node.getNodeName().equals("geek")) {
        	assert true;
        }else {
        	assert false;
        }
        if (node.getNodeType()
            == Node.ELEMENT_NODE) {
            Element tElement = (Element)node;
            try {
				Double.parseDouble(tElement
                      .getElementsByTagName("id")
                      .item(0)
                      .getTextContent());
				System.out.println("Datatype is Numeric");
				return;
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Datatype isn't Numeric");
				return;
			}
            
        }
    }


	}

}
