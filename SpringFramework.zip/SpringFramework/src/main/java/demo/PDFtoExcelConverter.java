package demo;

import com.aspose.pdf.Document;
import com.aspose.pdf.ExcelSaveOptions;

public class PDFtoExcelConverter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Load PDF document
		Document document = new Document("C:\\Users\\babua\\Downloads\\Holiday Calendar List - 2022- India.pdf");
		// Instantiate ExcelSave Option object
		ExcelSaveOptions excelsave = new ExcelSaveOptions();
		// Save the output to XLS format
		document.save("ConvertedFile.xls", excelsave);
	}

}
